<?php return array (
  'transaksi-pembayaran-livewire' => 'App\\Http\\Livewire\\TransaksiPembayaranLivewire',
);