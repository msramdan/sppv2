<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PengaturanSekolah extends Model
{
    protected $guarded = [];

    protected $table = 'pengaturan_sekolah';
}
