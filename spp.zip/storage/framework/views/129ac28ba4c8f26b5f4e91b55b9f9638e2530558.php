

<?php $__env->startSection('content'); ?>
<section class="section">
    <!-- Content Header (Page header) -->
    <section class="section-header ">
        <h1>Manajemen Kelas</h1>
        <div class="section-header-breadcrumb">
            <div class="breadcrumb-item active"><a href="<?php echo e(route('home')); ?>">Dashboard</a></div>
            <div class="breadcrumb-item">Kelas</div>
        </div>
    </section>

    <!-- Main content -->
    <section class="section-body">

        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header iseng-sticky bg-white">
                        <h4>Laporan Pembayaran</h4>
                        <div class="card-header-action">
                            <a href="<?php echo e(route('kelas.create')); ?>" class="btn btn-primary btn-icon"
                                data-toggle="tooltip" data-placement="top" title=""
                                data-original-title="Tambah Data">
                                <i class="fas fa-plus-circle px-2    "></i>
                            </a>
                            
                        </div>
                    </div>
                    <!-- /.card-header -->
                    <div class="card-body">
                        <form action="<?php echo e(route('laporan.pembayaran')); ?>" method="GET">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="start_date">Dari Tanggal</label>
                                    <input type="date"
                                        class="form-control" name="start_date" value="<?php echo e((!empty(request()->start_date)) ? request()->start_date : old('start_date')); ?>" id="start_date" aria-describedby="helpId" placeholder="">
                                    <?php $__errorArgs = ['start_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="text-danger small mt-1"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="form-group">
                                    <label for="end_date">Sampai Tanggal</label>
                                    <input type="date"
                                        class="form-control" name="end_date" value="<?php echo e((!empty(request()->end_date)) ? request()->end_date : old('end_date')); ?>" id="end_date" aria-describedby="helpId" placeholder="">
                                        <?php $__errorArgs = ['end_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="text-danger small mt-1"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="mode">Mode</label>
                                    <select class="form-control" name="mode" id="mode" required>
                                        <option value="">Pilih</option>
                                        <option value="simple" <?php echo e((request()->mode === 'simple') ? 'selected' : ''); ?>>Simple</option>
                                        <option value="detail" <?php echo e((request()->mode === 'detail') ? 'selected' : ''); ?>>Detail</option>
                                    </select>
                                    <?php $__errorArgs = ['mode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="text-danger small mt-1"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="form-group">
                                    <label for="jenisPembayaran">Jenis Pembayaran</label>
                                    <select class="form-control" name="jenisPembayaran" id="jenisPembayaran">
                                        <option value="">Pilih</option>
                                        <?php $__currentLoopData = $jenisPembayaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->nama_pembayaran); ?>" <?php echo e((request()->jenisPembayaran === $item->nama_pembayaran) ? 'selected' : ''); ?>><?php echo e($item->nama_pembayaran); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php $__errorArgs = ['jenisPembayaran'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="text-danger small mt-1"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="form-group">
                                    <button type="submit" class="btn btn-info float-right">Tampilkan</button>
                                </div>
                            </div>
                        </div>
                        </form>
                        <hr>
                        <?php if(!empty($data)): ?>
                            <div class="div">
                                <a href="<?php echo e(route('laporan.pembayaranPdf')); ?>" target="blank" class="btn btn-light">
                                    <i class="fas fa-file-pdf    "></i>
                                    PDF
                                </a>
                                <?php if(request()->mode === 'simple'): ?>
                                    
                                <a href="<?php echo e(route('laporan.pembayaranExcel')); ?>" target="blank" class="btn btn-light">
                                    <i class="fas fa-file-pdf    "></i>
                                    Excel
                                </a>
                                <?php endif; ?>
                            </div>
                            <?php if(request()->mode === 'simple'): ?>
                                <div class="table-responsive">
                                    <table class="table table-head-fixed table-bordered table-stripe mt-4">
                                        <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>Tgl.Pembayaran</th>
                                                <th>
                                                    NIS/Nama
                                                </th>
                                                <th>Nama Pembayaran</th>
                                                <th>Keterangan</th>
                                                
                                                <th class="text-right">Jumlah Bayar</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td style="width: 50px">
                                                        <?php echo e($loop->iteration); ?>

                                                    </td>
                                                    <td >
                                                        <?php echo e(date_format(date_create($row->transaksi_pembayaran->created_at), 'd-m-Y')); ?>

                                                    </td>
                                                    <td>
                                                        <?php echo e(@$row->transaksi_pembayaran->siswa->nis); ?> <br>
                                                        <?php echo e(@$row->transaksi_pembayaran->siswa->nama_lengkap); ?>

                                                    </td>
                                                    <td>
                                                        <?php echo e($row->nama_pembayaran); ?>

                                                    </td>
                                                    <td>
                                                        <?php echo e($row->keterangan); ?>

                                                    </td>
                                                    <td class="text-right">
                                                        Rp.<?php echo e(number_format($row->harga)); ?>

                                                    </td>
                                                </tr>                                  
                                                    
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
                                        </tbody>
                                    </table>

                                </div>
                            <?php else: ?>
                                <div class="table-responsive">
                                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <table class="table table-head-fixed text-nowrap table-bordered table-stripe mt-4">
                                        <thead>
                                            <tr>
                                                
                                                <th><?php echo e($loop->iteration); ?></th>
                                                <th>
                                                    Tanggal Pembayaran : <br>
                                                    <?php echo e(date_format(date_create($row->created_at), 'd-m-Y')); ?>

                                                </th>
                                                <th><?php echo e(@$row->siswa->nis); ?> -   
                                                    <?php echo e(@$row->siswa->kelas->nama_kelas); ?><br>
                                                    <strong><?php echo e(@$row->siswa->nama_lengkap); ?></strong> <br></th>
                                                <th>Metode Pembayaran <br> <?php echo e($row->metode_pembayaran); ?></th>
                                                
                                                <th class="text-right">Total Bayar <br> Rp.<?php echo e(number_format($row->total)); ?></th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                                <?php $__currentLoopData = $row->detail_pembayaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td style="width: 50px"></td>
                                                    <td colspan="3">
                                                        <?php echo e($item->nama_pembayaran); ?> - <?php echo e($item->keterangan); ?>

                                                    </td>
                                                    
                                                    <td class="text-right">
                                                        Rp.<?php echo e(number_format($item->harga)); ?>

                                                    </td>
                                                </tr>                                  
                                                    
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
                                        </tbody>
                                    </table>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            <?php endif; ?>

                        <?php endif; ?>    
                    </div>
                    <!-- /.card-body -->
                    <div class="card-footer">
                        
                    </div>
                </div>
                <!-- /.card -->
            </div>
        </div>

    </section>
    <!-- /.content -->
</section>

<!-- Modal Delete-->
<div class="modal fade" id="deleteModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="deleteModalLabel">Hapus Data Kelas</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <p class="mt-3">Apakah kamu yakin menghapus Data Kelas ?</p>
            </div>
            <div class="modal-footer">
                <form action="" method="POST" id="deleteForm">
                    <?php echo method_field('DELETE'); ?>
                    <?php echo csrf_field(); ?>
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Tidak, Kembali</button>
                    <button type="submit" class="btn btn-danger">Ya, Hapus</button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    function handleDelete(id) {
        let form = document.getElementById('deleteForm')
        form.action = `./kelas/${id}`
        console.log(form)
        $('#deleteModal').modal('show')
    }

</script>

<?php if(session()->has('success')): ?>
    <script>
        $(document).ready(function () {
            // toastr["success"]('<?php echo e(session()->get('success')); ?>')
            iziToast.success({
                title: '',
                message: '<?php echo e(session()->get('success')); ?>',
                position: 'bottomCenter'
            });
        });

    </script>
<?php endif; ?>

<?php if(session()->has('error')): ?>
    <script>
        $(document).ready(function () {
            // toastr["info"]('<?php echo e(session()->get('error')); ?>')
            iziToast.info({
                title: '',
                message: '<?php echo e(session()->get('success')); ?>',
                position: 'bottomCenter'
            });
        });

    </script>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel New\spp\resources\views/admin/laporan/index.blade.php ENDPATH**/ ?>