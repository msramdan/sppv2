

<?php $__env->startSection('content'); ?>
<section class="section">
    <!-- Content Header (Page header) -->
    <section class="section-header ">
        <h1>Manajemen Users</h1>
        <div class="section-header-breadcrumb">
            <div class="breadcrumb-item active"><a href="<?php echo e(route('home')); ?>">Dashboard</a></div>
            <div class="breadcrumb-item">Users</div>
        </div>
    </section>

    <!-- Main content -->
    <section class="section-body">

        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header iseng-sticky bg-white">
                        <h4>List Data Users</h4>
                        <div class="card-header-action">
                            <a href="<?php echo e(route('users.create')); ?>" class="btn btn-primary btn-icon"
                                data-toggle="tooltip" data-placement="top" title=""
                                data-original-title="Tambah Data User">
                                <i class="fas fa-plus-circle px-2    "></i>
                            </a>
                        </div>
                    </div>
                    <!-- /.card-header -->
                    <div class="card-body" >
                        <form action="<?php echo e(route('users.index')); ?>" method="GET">
                            
                            <div class="input-group input-group mb-3 float-right" style="width: 250px;">
                                <input type="text" name="keyword" class="form-control float-right"
                                placeholder="Search" value="<?php echo e(request()->query('keyword')); ?>">
    
                                
                                <div class="input-group-append">
                                    <button type="submit" class="btn btn-light"><i class="fas fa-search"></i></button>
                                </div>
                                <div class="input-group-append">
                                    <a href="<?php echo e(route('users.index')); ?>" title="Refresh" class="btn btn-light"><i class="fas fa-circle-notch mt-2   "></i></a>
                                </div>
                            </div>
                        </form>
                        <div class="table-responsive">
                            <table class="table table-head-fixed text-nowrap  table-bordered">
                                <thead>
                                    <tr class="text-center">
                                        <th style="width: 20px">#</th>
                                        <th style="width: 50px">No</th>
                                        <th>Nama</th>
                                        <th>Username</th>
                                        <th>Email</th>
                                        <th>Status</th>
                                        <th>Role</th>
                                        
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td>
                                            <div class="btn-group">
                                                <button type="button" class="btn px-1" data-toggle="dropdown">
                                                    <i class="fas fa-ellipsis-v    "></i>
                                                </button>
                                                <ul class="dropdown-menu">
                                                    <li>
                                                        <a class="dropdown-item"
                                                            href="<?php echo e(route('users.edit', $row->id)); ?>">
                                                            <i class="fas fa-edit    "></i>
                                                            Edit
                                                        </a>
                                                    </li>
                                                    <li>
                                                        <a class="dropdown-item" href="#" onclick="handleDelete (<?php echo e($row->id); ?>)" >
                                                            <i class="fas fa-trash"></i>
                                                            Delete
                                                        </a>
                                                    </li>
                                                </ul>
                                            </div>
                                        </td>
                                        <td class="text-center">
                                            <?php echo e($loop->iteration + $users->firstItem() - 1); ?>

                                        </td>
                                        <td><?php echo e($row->name); ?></td>
                                        <td><?php echo e($row->username); ?></td>
                                        <td><?php echo e($row->email); ?></td>
                                        <td class="text-center">
                                            <?php if($row->status == 1): ?>
                                                <div class="badge badge-success">Aktif</div>
                                            <?php else: ?> 
                                                <div class="badge badge-warning">Non Aktif</div>
                                            <?php endif; ?>
                                        </td>
                                        <td class="text-center"><span class="tag tag-success"><?php echo e($row->roles->first()->name); ?></span></td>
                                        
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <tr>
                                            <td colspan="4" class="text-center">Data Tidak Ada</td>
                                        </tr>
                                    <?php endif; ?>
                                    
                                </tbody>
                            </table>
                            <?php echo e($users->appends(['keyword' => request()->query('keyword')])->links()); ?>

                        </div>

                    </div>
                    <!-- /.card-body -->
                    <div class="card-footer clearfix">
                        <span class="text-sm float-right">Total Entries : <?php echo e($users->total()); ?></span>
                    </div>
                </div>
                <!-- /.card -->
            </div>
        </div>

    </section>
    <!-- /.content -->
</section>

<!-- Modal Delete-->
<div class="modal fade" id="deleteModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
    <div class="modal-content">
        <div class="modal-header">
        <h5 class="modal-title" id="deleteModalLabel">Hapus Data Users</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
        </div>
        <div class="modal-body">
            <p class="mt-3">Apakah kamu yakin menghapus Data Users ini  ?</p>
            <p><strong>Mendelete / menghapus user bisa menyebabkan Error, disarankan untuk tidak menghapus user.</strong></p>
            <p><strong> Sebaiknya rubah status user menjadi Non Aktif jika tidak digunakan lagi.</strong></p>
        </div>
        <div class="modal-footer">
            <form action="" method="POST" id="deleteForm">
                <?php echo method_field('DELETE'); ?>
                <?php echo csrf_field(); ?>
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Tidak, Kembali</button>
                <button type="submit" class="btn btn-danger">Ya, Hapus</button>
            </form>
        </div>
    </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        function handleDelete(id){
            let form = document.getElementById('deleteForm')
            form.action = `./users/${id}`
            console.log(form)
            $('#deleteModal').modal('show')
        }  
    </script>

    <?php if(session()->has('success')): ?>
    <script>
        $(document).ready(function() {
            // toastr["success"]('<?php echo e(session()->get('success')); ?>')
            iziToast.success({
                title: '',
                message: '<?php echo e(session()->get('success')); ?>',
                position: 'bottomCenter'
            });
        });
    </script>
    <?php endif; ?>

    <?php if(session()->has('error')): ?>
    <script>
        $(document).ready(function () {
            // toastr["info"]('<?php echo e(session()->get('error')); ?>')
            iziToast.info({
                title: '',
                message: '<?php echo e(session()->get('error')); ?>',
                position: 'bottomCenter'
            });
        });

    </script>
    <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel New\spp\resources\views/users/index.blade.php ENDPATH**/ ?>