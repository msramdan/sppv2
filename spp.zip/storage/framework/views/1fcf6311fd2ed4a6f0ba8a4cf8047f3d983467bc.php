

<?php $__env->startSection('css'); ?>
    <?php echo \Livewire\Livewire::styles(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="section">
        <!-- Content Header (Page header) -->
        <section class="section-header ">
            <h1>Manajemen Transaksi Pembayaran</h1>
            <div class="section-header-breadcrumb">
                <div class="breadcrumb-item active"><a href="<?php echo e(route('home')); ?>">Dashboard</a></div>
                <div class="breadcrumb-item active"><a href="<?php echo e(route('pembayaran.index')); ?>">Pembayaran</a>
                </div>
                <div class="breadcrumb-item">Transaksi Pembayaran</div>
            </div>
        </section>

        <!-- Main content -->
        <section class="section-body">

            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header iseng-sticky bg-white">
                            <a href="<?php echo e(route('pembayaran.index')); ?>" class="btn">
                                <i class="fas fa-arrow-left  text-dark  "></i>
                            </a>
                            <h4 class="ml-3">Form Transaksi Pembayaran</h4>
                        </div>
                        <!-- /.card-header -->
                        <div class="card-body">
                            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('transaksi-pembayaran-livewire', [])->html();
} elseif ($_instance->childHasBeenRendered('rq8meHw')) {
    $componentId = $_instance->getRenderedChildComponentId('rq8meHw');
    $componentTag = $_instance->getRenderedChildComponentTagName('rq8meHw');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('rq8meHw');
} else {
    $response = \Livewire\Livewire::mount('transaksi-pembayaran-livewire', []);
    $html = $response->html();
    $_instance->logRenderedChild('rq8meHw', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                        </div>
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->
                </div>
            </div>

        </section>
        <!-- /.content -->
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <?php echo \Livewire\Livewire::scripts(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel New\spp\resources\views/admin/pembayaran/transaksi.blade.php ENDPATH**/ ?>