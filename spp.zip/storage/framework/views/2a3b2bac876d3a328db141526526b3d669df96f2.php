<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Data Produk</title>

</head>

<body>
    <div class="header">
        <h4><?php echo e($sekolahInfo->nama_sekolah); ?></h4>
        <h4><?php echo e($sekolahInfo->alamat); ?> <?php echo e($sekolahInfo->kota); ?></h4>
        <h4>No. Telpon : <?php echo e($sekolahInfo->no_telp); ?></h4>
        
    </div>
    <p></p>
    <?php if(!empty($jenisPembayaranTipe)): ?>
        <div class="customer">
            <table>
                <tr>
                    <th>Jenis Pembayaran</th>
                    <td></td>
                    <td><?php echo e($data->first()->jenis_pembayaran->nama_pembayaran); ?></td>
                </tr>
                <tr>
                    <th>Tahun Pelajaran</th>
                    <td></td>
                    <td><?php echo e($data->first()->jenis_pembayaran->tahunajaran->tahun_ajaran); ?></td>
                </tr>
                <tr>
                    <th>Nominal</th>
                    <td></td>
                    <td>Rp. <?php echo e(number_format($data->first()->jenis_pembayaran->harga)); ?></td>
                </tr>
                <tr>
                    <th>Tipe</th>
                    <td></td>
                    <td><?php echo e($jenisPembayaranTipe === 'bulanan' ? 'Bulanan' : 'Angsuran/Bebas'); ?></td>
                </tr>
                <tr>
                    <th>Kelas</th>
                    <td></td>
                    <td><?php echo e($namaKelas == '' ? 'Semua Kelas' : $namaKelas); ?></td>
                </tr>
            </table>
        </div>
        
    <?php else: ?>
        <p>Dicetak Tanggal : <?php echo e(date('d-m-Y')); ?></p>
        <p></p>
        <p></p>
    <?php endif; ?>
    <div class="page">
        <table>
            <thead>
                <tr>
                    <th style="text-align:center; border: 1px solid black">#</th>
                    <th style="text-align:center; border: 1px solid black">Nis</th>
                    <th style="text-align:center; border: 1px solid black">Nama</th>
                    <th style="text-align:center; border: 1px solid black">Kelas</th>

                    <?php if($jenisPembayaranTipe === 'bulanan'): ?>
                        <?php $__currentLoopData = $bulan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <th style="text-align:center; border: 1px solid black"><?php echo e($item); ?></th>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <th style="text-align:center; border: 1px solid black">Total</th>
                        <th style="text-align:center; border: 1px solid black">Sisa</th>
                    <?php else: ?>
                        <th style="text-align:center; border: 1px solid black">
                            Status
                        </th>
                        <th style="text-align:center; border: 1px solid black">Total Bayar</th>
                        <th style="text-align:center; border: 1px solid black">Sisa</th>
                    <?php endif; ?>
                </tr>
            </thead>
            <tbody>
                <?php
                    $grandTotal = 0;
                    $totalBayar = 0;
                    $totalSisa = 0;
                    $sisa = 0;
                ?>
                <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td style="text-align:center; border: 1px solid black"><?php echo e($loop->iteration); ?></td>

                        <td style="text-align:center; border: 1px solid black"><?php echo e($row->siswa->nis); ?></td>

                        <td style="text-align:left; border: 1px solid black"><?php echo e($row->siswa->nama_lengkap); ?></td>

                        <td style="text-align:left; border: 1px solid black">
                            <?php echo e($row->siswa->kelas->nama_kelas); ?>

                        </td>

                        <?php
                            $total = 0;
                        ?>

                        <?php $__currentLoopData = $row->tagihan_detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <td style="text-align:center; border: 1px solid black;">
                                <?php if($item->status === 'Lunas'): ?>
                                    Lunas
                                    <?php
                                        $total = $total + $data->first()->jenis_pembayaran->harga;
                                    ?>
                                <?php endif; ?>

                                <?php if($item->status === 'Belum Lunas'): ?>
                                    -
                                    <br>
                                    <small style="margin-bottom: 0">Dibayar: Rp.
                                        Rp. <?php echo e(number_format($item->total_bayar)); ?></small>
                                    <br>
                                    <small style="margin-top: 0">Sisa: Rp.
                                        Rp. <?php echo e(number_format($item->sisa)); ?></small>
                                    <?php
                                        $sisa += $item->sisa;
                                        $total += $item->total_bayar;
                                    ?>
                                <?php endif; ?>

                            </td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php if($jenisPembayaranTipe !== 'bulanan'): ?>
                            <td style="text-align:right; border: 1px solid black">
                                Rp. <?php echo e(number_format($row->tagihan_detail[0]->total_bayar)); ?>


                                <?php if($row->tagihan_detail[0]->total_bayar != 0): ?>
                                    <?php
                                        $totalBayar = $totalBayar + $row->tagihan_detail[0]->total_bayar;
                                    ?>
                                <?php endif; ?>
                            </td>
                            <td style="text-align:right; border: 1px solid black">
                                Rp. <?php echo e(number_format($row->tagihan_detail[0]->sisa)); ?>

                            </td>
                        <?php endif; ?>


                        <?php
                            $grandTotal += $total;
                            $totalSisa += $sisa;
                        ?>

                        <?php if($jenisPembayaranTipe === 'bulanan'): ?>
                            <td style="text-align:right; border: 1px solid black;">Rp. <?php echo e(number_format($total)); ?>

                            </td>

                            <td style="text-align:right; border: 1px solid black;">Rp. <?php echo e(number_format($sisa)); ?>

                            </td>
                            <?php
                                // set sisa ke 0 lagi
                                $sisa = 0;
                            ?>
                        <?php endif; ?>
                        
                    </tr>


                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="5" class="text-center">Tidak ada data</td>
                    </tr>
                <?php endif; ?>

                <?php if($jenisPembayaranTipe === 'bulanan'): ?>
                    <tr>
                        <td colspan="9" style="text-align:right; border: 1px solid black;"></td>

                        <td colspan="1" style="text-align:right; border: 1px solid black;">Grand Total </td>

                        <td style="text-align:right; border: 1px solid black;">Rp. <?php echo e(number_format($grandTotal)); ?>

                        </td>

                        <td style="text-align:right; border: 1px solid black;">
                            Rp. <?php echo e(number_format($totalSisa)); ?>

                        </td>
                    </tr>
                <?php else: ?>
                    <tr>
                        
                        <td colspan="5" style="text-align:right; border: 1px solid black;">Grand Total </td>

                        <td style="text-align:right; border: 1px solid black;">Rp. <?php echo e(number_format($totalBayar)); ?>

                        </td>

                        <td style="text-align:right; border: 1px solid black;">
                            Rp. <?php echo e(number_format($totalSisa)); ?>

                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</body>

</html>
<?php /**PATH D:\Laravel New\spp\resources\views/admin/laporan/exportTagihanExcel.blade.php ENDPATH**/ ?>