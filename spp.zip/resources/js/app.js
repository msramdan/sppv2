require('./bootstrap');

require('admin-lte/plugins/select2/js/select2.full')
